import json
import gspread
import telebot
from google.oauth2.service_account import Credentials
from flask import Flask
from flask_cors import CORS
from google import genai
from groq import Groq

from config import (
    TELEGRAM_BOT_TOKEN, GEMINI_API_KEY, GROQ_API_KEY,
    GOOGLE_CREDENTIALS_JSON, SPREADSHEET_ID
)

bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)
app = Flask(__name__)
CORS(app)

gemini_client = genai.Client(api_key=GEMINI_API_KEY) if GEMINI_API_KEY else None
groq_client = Groq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None

sheet = None
spreadsheet = None

def init_google_sheets():
    global sheet, spreadsheet
    if not GOOGLE_CREDENTIALS_JSON or not SPREADSHEET_ID:
        print("ℹ️ Google Sheets sozlamalari berilmagan.")
        return

    try:
        cred_info = json.loads(GOOGLE_CREDENTIALS_JSON)
        scopes = [
            "https://spreadsheets.google.com/feeds",
            "https://www.googleapis.com/auth/drive",
        ]
        credentials = Credentials.from_service_account_info(cred_info, scopes=scopes)
        gc = gspread.authorize(credentials)
        spreadsheet = gc.open_by_key(SPREADSHEET_ID)
        sheet = spreadsheet.sheet1
        print("✅ Google Sheets ulandi!")
    except Exception as e:
        print(f"⚠️ Google Sheets ulanishda xatolik: {e}")
