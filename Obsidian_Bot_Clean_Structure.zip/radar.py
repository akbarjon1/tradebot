
import datetime
import json
import time
import requests
from clients import bot
from config import CHANNEL_CHAT_ID
from ai import get_ai_analysis
from sheets import save_trade_to_sheets
import state


def scan_and_post_ai_signals():
    """Har 15 daqiqada shamchalarni ICT / Smart Money qoidalarida tekshiruvchi modul"""
    symbols = ["BTCUSDT", "ETHUSDT"]
    print("🚀 [AI Radar // ICT Edition] Smart Money skaneri ishga tushdi!")
    
    while True:
        try:
            for sym in symbols:
                url = f"https://api.binance.com/api/v3/klines?symbol={sym}&interval=15m&limit=25"
                res = requests.get(url, timeout=10)
                if res.status_code != 200:
                    continue

                candles_raw = res.json()
                current_price = float(candles_raw[-1][4])

                candles_ohlc = []
                for c in candles_raw[-15:]:
                    t_str = datetime.datetime.fromtimestamp(c[0]/1000).strftime("%H:%M")
                    candles_ohlc.append({
                        "t": t_str,
                        "open": float(c[1]),
                        "high": float(c[2]),
                        "low": float(c[3]),
                        "close": float(c[4])
                    })

                prompt = f"""
Sen ICT (Inner Circle Trader) va Smart Money Concepts bo'yicha professional institutsional treydersan.
Quyida {sym} aktivining 15 daqiqalik so'nggi shamchalari berilgan (Open, High, Low, Close):
{json.dumps(candles_ohlc)}
Joriy jonli narx: {current_price}

Quyidagi ICT konseptlarini qat'iy tekshir:
1. Liquidity Sweep / Turtle Soup: Narx oldingi asosiy High (Buy-side) yoki Low (Sell-side) likvidligini olib, orqasiga qaytdimi?
2. CISD (Change In State of Delivery / Market Structure Shift): Yetkazib berish holati o'zgardimi, impulsiv qarama-qarshi shamcha paydo bo'ldimi?
3. FVG (Fair Value Gap): 3 ta ketma-ket shamcha oralig'ida Imbalance (muvozanatsizlik) bormi va narx unga mitigatsiya qildimi?
4. Target (BSL yoki SSL): Qarama-qarshi tomondagi likvidlik hovuzi qayerda?

Agar bozorda to'laqonli ICT kirish nuqtasi (Turtle Soup + CISD + FVG) shakllangan bo'lsa, xabarni aynan "SIGNAL_FOUND" bilan boshla:
SIGNAL_FOUND
📍 Yo'nalish: [LONG yoki SHORT]
🎯 Take-Profit (BSL/SSL): [aniq narx]
🛑 Stop-Loss (Invalidation): [aniq narx]
💡 ICT Tahlil: [Qaysi likvidlik olingani, FVG va CISD qanday yuz berganini 1-2 jumlada o'zbek tilida professional ifoda et]

Agar bozor flat bo'lsa, likvidlik olinmagan bo'lsa yoki shartlar to'liq bo'lmasa, FAQAT "NO_SIGNAL" deb yoz. Boshqa so'z qo'shma.
"""
                ai_verdict = get_ai_analysis(prompt)

                if ai_verdict and "SIGNAL_FOUND" in ai_verdict:
                    clean_text = ai_verdict.replace("SIGNAL_FOUND", "").strip()

                    uzb_time = datetime.datetime.utcnow() + datetime.timedelta(hours=5)
                    now_time = uzb_time.strftime("%H:%M")

                    state.latest_ict_status["BTC" if "BTC" in sym else "ETH"] = f"ICT Setup detected on {sym}!"

                    post_caption = (
                        f"⚡️ <b>OBSIDIAN RADAR // ICT ALGO SIGNAL</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"📊 <b>Aktiv:</b> #{sym}\n"
                        f"💵 <b>Narx:</b> ${current_price:,.2f}\n"
                        f"⏱ <b>Vaqt:</b> {now_time}\n\n"
                        f"{clean_text}\n\n"
                        f"⚠️ <i>Kotletit qilmang, risk-menejment qoidalariga rioya qiling!</i>\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"🌐 <a href='https://tradebot-xelo.onrender.com'>Web Terminalda ochish</a>"
                    )

                    chart_url = "https://charts.bitbo.io/chart-images/btc-usd-1d.png"
                    img_sent = False

                    try:
                        resp = requests.get(chart_url, timeout=8)
                        if resp.status_code == 200:
                            bot.send_photo(CHANNEL_CHAT_ID, resp.content, caption=post_caption, parse_mode="HTML")
                            img_sent = True
                    except Exception as img_err:
                        print(f"Rasm yuklashda ogohlantirish: {img_err}")

                    if not img_sent:
                        bot.send_message(CHANNEL_CHAT_ID, post_caption, parse_mode="HTML")

                    save_trade_to_sheets(f"ICT: {sym}", clean_text)
                    print(f"LOG: [AI Radar // ICT] {sym} bo'yicha Smart Money signali kanalga chiqdi!")
                else:
                    state.latest_ict_status["BTC" if "BTC" in sym else "ETH"] = f"Scanning {sym} 15m Liquidity..."

                time.sleep(5)

        except Exception as err:
            print(f"LOG: [AI Radar // ICT] Skanerda ogohlantirish: {err}")

        time.sleep(900)

