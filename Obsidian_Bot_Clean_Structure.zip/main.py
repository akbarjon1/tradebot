import time
import threading
from clients import app, bot, init_google_sheets
from config import WEBHOOK_URL
import web
import handlers
import radar
import monitoring
import news

def run_flask():
    import os
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)

def setup_webhook():
    try:
        bot.remove_webhook()
        time.sleep(1)
        result = bot.set_webhook(url=WEBHOOK_URL, drop_pending_updates=True)
        print(f"✅ Telegram Webhook o'rnatildi: {WEBHOOK_URL}")
        print(f"✅ Telegram webhook result: {result}")
    except Exception as e:
        print(f"❌ Telegram webhook o'rnatilmadi: {e}")

def start_background_workers():
    threading.Thread(target=monitoring.monitor_new_trades, daemon=True).start()
    threading.Thread(target=news.fetch_and_post_crypto_news, daemon=True).start()
    threading.Thread(target=radar.scan_and_post_ai_signals, daemon=True).start()

def main():
    init_google_sheets()
    threading.Thread(target=run_flask, daemon=True).start()
    start_background_workers()
    setup_webhook()

    # Flask daemon thread runs the HTTP server; keep the Render process alive.
    while True:
        time.sleep(3600)

if __name__ == "__main__":
    main()
