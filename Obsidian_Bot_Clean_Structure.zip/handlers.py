
from clients import bot
from config import ADMIN_USER_IDS, CHANNEL_CHAT_ID
from ai import get_ai_analysis
from sheets import save_trade_to_sheets
import state
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, WebAppInfo


@bot.message_handler(commands=['start'])
def handle_start(message):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    tma_button = KeyboardButton(
        text="🚀 Savdo Terminalini ochish", 
        web_app=WebAppInfo(url="https://akbarjon1.github.io/tradebot/")
    )
    markup.add(tma_button)

    bot.reply_to(
        message, 
        "⚡️ *Obsidian Lab Paper-Trading platformasiga xush kelibsiz!*\n\n"
        "Virtual $10,000 balans bilan savdo qilish uchun quyidagi tugmani bosing:\n\n"
        "🛠 _Adminlar uchun test buyrug'i:_ `/test_signal`",
        reply_markup=markup,
        parse_mode="Markdown"
    )

@bot.message_handler(commands=['test_signal'])
def handle_test_signal(message):
    if ADMIN_USER_IDS and str(message.from_user.id) not in ADMIN_USER_IDS:
        bot.reply_to(message, "⛔️ Bu buyruq faqat adminlar uchun.")
        return

    uzb_time = datetime.datetime.utcnow() + datetime.timedelta(hours=5)
    now_time = uzb_time.strftime("%H:%M")
    
    test_caption = (
        f"⚡️ <b>OBSIDIAN RADAR // ICT ALGO SIGNAL</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>Aktiv:</b> #BTCUSDT\n"
        f"💵 <b>Narx:</b> $76,300.00\n"
        f"⏱ <b>Vaqt:</b> {now_time}\n\n"
        f"📍 <b>Yo'nalish:</b> LONG 🟢\n"
        f"🎯 <b>Take-Profit (BSL):</b> $78,500.00\n"
        f"🛑 <b>Stop-Loss (Invalidation):</b> $75,100.00\n"
        f"💡 <b>ICT Tahlil:</b> 15m Sell-side likvidligi (Turtle Soup) yechildi va bullish CISD yuz berdi. Narx $75,800 FVG zonasiga mitigatsiya qilib yuqoriga qaytmoqda.\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"🌐 <a href='https://tradebot-xelo.onrender.com'>Web Terminalda ochish</a>"
    )
    chart_url = "https://charts.bitbo.io/chart-images/btc-usd-1d.png"

    try:
        resp = requests.get(chart_url, timeout=8)
        if resp.status_code == 200:
            bot.send_photo(CHANNEL_CHAT_ID, resp.content, caption=test_caption, parse_mode="HTML")
        else:
            bot.send_message(CHANNEL_CHAT_ID, test_caption, parse_mode="HTML")
        bot.reply_to(message, "✅ ICT test signali kanalga muvaffaqiyatli yuborildi!")
    except Exception as e:
        try:
            bot.send_message(CHANNEL_CHAT_ID, test_caption, parse_mode="HTML")
            bot.reply_to(message, "✅ Test signali matn ko'rinishida kanalga yuborildi!")
        except Exception as err2:
            bot.reply_to(message, f"❌ Kanalga yuborishda xatolik: {err2}")

@bot.message_handler(func=lambda message: True)
def handle_trade_message(message):
    user_text = message.text
    user_id = message.from_user.id

    if user_id not in state.user_histories:
        state.user_histories[user_id] = []

    history_text = "\n".join(state.user_histories[user_id][-6:])

    prompt = (
        "Sen — Toshkentlik kripto-treyder do'stsan. Telegramda yaqin do'sting bilan chatlashyapsan.\n\n"
        "XARAKTERING VA USLUBING:\n"
        "- Jonli, hazilkash, biroz kinoyali, ko'cha tilida erkin gapir.\n"
        "- Gaplaring o'ta qisqa bo'lsin (bir necha so'z yoki bitta jumla).\n"
        "- 'Men ham dam olib uxlayman', 'Yaxshi, keyin gaplashamiz' degan robot gaplarni QAT'IYAN ISHLATMA!\n"
        "- Masalan: 'uxla' desa -> 'O'zing uxla brat, grafik qarab o'tiribman' yoki 'Bozor uxlamaydi, bizga dam yo'q' deb javob ber.\n"
        "- 'tur' desa -> 'Uyg'oqman, nima gap?' deb javob ber.\n"
        "- Bozor bo'yicha aniq signal bo'lmasa, o'zingdan yolg'on narx to'qima, 'Grafikni ko'rish kerak, hozircha noaniq' deb ayt.\n\n"
        f"Oldingi gaplar:\n{history_text}\n\n"
        f"Do'sting: {user_text}\n"
        "Sen:"
    )

    try:
        content = get_ai_analysis(prompt)
        if not content:
            bot.send_message(message.chat.id, "Ey jigar, tarmoqda tiqilinch bo'p qoldi, birozdan keyin yozvor.")
            return

        state.user_histories[user_id].append(f"Foydalanuvchi: {user_text}")
        state.user_histories[user_id].append(f"Sen: {content}")
        # Xotirada cheksiz o'sib ketmasligi uchun oxirgi 20 ta yozuvni saqlaymiz
        state.user_histories[user_id] = state.user_histories[user_id][-20:]

        if content.startswith("SIGNAL_DETECTED"):
            clean_content = content.replace("SIGNAL_DETECTED", "").strip()
            title = user_text[:30]
            success, msg = save_trade_to_sheets(title, clean_content)

            if success:
                reply_text = f"🎯 *Signal Google Sheets'ga qadab qo'yildi, brat!*\n\n{clean_content}\n\n⚠️ _Kotletit qilib yuborma, risk-menejment esdan chiqmasin!_"
            else:
                reply_text = f"⚠️ Tahlil tayyor, lekin Sheets'ga saqlanmadi: {msg}\n\n{clean_content}"
            bot.send_message(message.chat.id, reply_text, parse_mode="Markdown")
        else:
            bot.send_message(message.chat.id, content)

    except Exception as e:
        bot.send_message(message.chat.id, f"Brat, xatolik berdi: {e}")

