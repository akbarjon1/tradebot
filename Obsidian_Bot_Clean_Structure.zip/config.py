import os

def get_env(key, default=""):
    val = os.environ.get(key, default)
    return val.strip() if val else default

TELEGRAM_BOT_TOKEN = get_env("TELEGRAM_BOT_TOKEN")
GEMINI_API_KEY = get_env("GEMINI_API_KEY")
GROQ_API_KEY = get_env("GROQ_API_KEY")
SPREADSHEET_ID = get_env("SPREADSHEET_ID")
GOOGLE_CREDENTIALS_JSON = get_env("GOOGLE_CREDENTIALS_JSON")
CHANNEL_CHAT_ID = get_env("CHANNEL_CHAT_ID", "@obsidian_lab_uz")
ADMIN_CHAT_ID = get_env("ADMIN_CHAT_ID", CHANNEL_CHAT_ID)
ADMIN_USER_IDS = {uid.strip() for uid in get_env("ADMIN_USER_IDS").split(",") if uid.strip()}

WEBHOOK_BASE_URL = get_env("WEBHOOK_BASE_URL", "https://tradebot-xelo.onrender.com").rstrip("/")
WEBHOOK_PATH = f"/telegram/{TELEGRAM_BOT_TOKEN}"
WEBHOOK_URL = f"{WEBHOOK_BASE_URL}{WEBHOOK_PATH}"

if not TELEGRAM_BOT_TOKEN:
    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN o'rnatilmagan. Render Environment Variables ichiga qo'shing."
    )
