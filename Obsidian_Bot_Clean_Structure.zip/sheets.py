import datetime
import uuid
import clients
def get_trades_from_sheets():
    if not clients.sheet:
        return []
    try:
        records = clients.sheet.get_all_records()
        trades = []
        for r in records:
            trades.append({
                "id": str(r.get("ID", "")),
                "title": str(r.get("Sarlavha", "Nomsiz")),
                "content": str(r.get("Tahlil", "")),
                "date": str(r.get("Sana", ""))
            })
        return trades
    except Exception as e:
        print(f"Google Sheets o'qishda xatolik: {e}")
        return []

def save_trade_to_sheets(title, content):
    if not clients.sheet:
        return False, "Google Sheets ulanmagan"
    try:
        t_id = str(uuid.uuid4())[:8]
        uzb_time = datetime.datetime.utcnow() + datetime.timedelta(hours=5)
        date_str = uzb_time.strftime("%Y-%m-%d")
        
        clients.sheet.append_row([t_id, title[:100], content[:2000], date_str])
        return True, "Muvaffaqiyatli saqlandi"
    except Exception as e:
        err_msg = str(e)
        print(f"Google Sheets'ga yozishda xatolik: {err_msg}")
        return False, err_msg

