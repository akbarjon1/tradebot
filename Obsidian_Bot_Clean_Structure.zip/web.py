
import datetime
from flask import request, redirect, url_for, jsonify, render_template
from clients import app, bot
from config import ADMIN_CHAT_ID
import state
import clients
from ai import get_ai_analysis
from sheets import get_trades_from_sheets


state.comments_store = []

@app.route(WEBHOOK_PATH, methods=['POST'])
def telegram_webhook():
    try:
        update_json = request.get_data(as_text=True)
        if update_json:
            update = telebot.types.Update.de_json(update_json)
            bot.process_new_updates([update])
        return "OK", 200
    except Exception as e:
        print(f"⚠️ Telegram webhook update xatosi: {e}")
        return "OK", 200

@app.route('/', methods=['GET'])
def home():
    trades = get_trades_from_sheets()
    return render_template(
        'index.html',
        title="Obsidian Lab — Trade Smarter. Real Markets. Zero Risk.",
        username="@trader",
        api_base="https://tradebot-xelo.onrender.com",
        bot_url="https://t.me/your_bot_username",
        trades=trades,
        comments=state.comments_store
    )

@app.route('/add_comment', methods=['POST'])
def add_comment():
    user_comment = request.form.get('comment')
    if user_comment:
        uzb_time = datetime.datetime.utcnow() + datetime.timedelta(hours=5)
        now_time = uzb_time.strftime("%Y-%m-%d %H:%M")

        state.comments_store.insert(0, {
            'text': user_comment,
            'created_at': now_time
        })
        try:
            tg_text = (
                f"💬 *OBSIDIAN LAB // FEEDBACK*\n"
                f"⏱ *Vaqt:* `{now_time}`\n"
                f"👤 *Manba:* `Web Terminal`\n"
                f"───────────────────\n\n"
                f"📝 *Fikr / Izoh:*\n"
                f"« {user_comment} »\n\n"
                f"▫️ _Status: Qabul qilindi_"
            )
            bot.send_message(ADMIN_CHAT_ID, tg_text, parse_mode="Markdown")
        except Exception as e:
            print(f"Kanalga yuborishda xatolik: {e}")

    return redirect(url_for('home'))

@app.route('/api/update_balance', methods=['POST'])
def update_balance():
    global spreadsheet
    try:
        data = request.get_json(force=True) or {}
        user_id = str(data.get("user_id", "")).strip()
        username = str(data.get("username", "Trader")).strip()
        balance = float(data.get("balance", 10000.0))

        if not spreadsheet or not user_id:
            return jsonify({"status": "error", "message": "Noto'g'ri ma'lumot"}), 400

        ws = spreadsheet.worksheet("Leaderboard")
        all_vals = ws.get_all_values()

        row_to_update = None
        for i, row in enumerate(all_vals[1:], start=2):
            if len(row) >= 1 and row[0].strip() == user_id:
                row_to_update = i
                break

        formatted_bal = f"{balance:.2f}"

        if row_to_update:
            ws.update_cell(row_to_update, 2, username)
            ws.update_cell(row_to_update, 3, formatted_bal)
        else:
            ws.append_row([user_id, username, formatted_bal])

        return jsonify({"status": "success", "updated_row": row_to_update})
    except Exception as e:
        print(f"Xatolik update_balance: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/api/leaderboard', methods=['GET'])
def get_leaderboard():
    global spreadsheet
    try:
        if not spreadsheet:
            return jsonify({"status": "success", "leaders": []})

        try:
            ws = spreadsheet.worksheet("Leaderboard")
        except Exception:
            return jsonify({"status": "success", "leaders": []})

        records = ws.get_all_records()
        valid_leaders = []

        for r in records:
            raw_bal = str(r.get("Balance", "0")).replace(" ", "").replace("\xa0", "").replace(",", ".")
            try:
                bal_val = float(raw_bal)
            except Exception:
                bal_val = 0.0

            valid_leaders.append({
                "User ID": str(r.get("User ID", "")),
                "Username": str(r.get("Username", "Trader")),
                "Balance": bal_val
            })

        sorted_leaders = sorted(valid_leaders, key=lambda x: x["Balance"], reverse=True)[:10]
        return jsonify({"status": "success", "leaders": sorted_leaders})
    except Exception as e:
        print(f"Leaderboard olishda xatolik: {e}")
        return jsonify({"status": "error", "message": str(e)}), 500

# --- OBSIDIAN HQ: LIVE AGENT LOGS VA TASKS ENDPOINT ---
@app.route('/api/agent_tasks', methods=['GET'])
def get_agent_tasks():
    """Izometrik HQ ofisdagi Live Ticker va statuslar uchun jonli ma'lumotlar"""
    return jsonify({
        "status": "success",
        "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
        "agents": {
            "jasur": {
                "name": "Jasur",
                "role": "ICT Market Analyst",
                "current_task": latest_ict_status.get("BTC", "Scanning 15m Liquidity"),
                "location": "Central Desk"
            },
            "alex": {
                "name": "Alex",
                "role": "Algo & Quant Dev",
                "current_task": "Backtesting CISD v2.4",
                "location": "Server Terminal"
            },
            "whale": {
                "name": "Mister Whale",
                "role": "Capital & Risk Manager",
                "current_task": "Reviewing Portfolio PnL",
                "location": "VIP Lounge"
            }
        },
        "logs": [
            f"⚡️ Jasur: {latest_ict_status.get('BTC')}",
            "💻 Alex: PineScript & Python ICT Engine online",
            "🐋 Mister Whale: Risk threshold set to 1.5% max drawdown",
            "📡 Network: Binance 15m WebSocket latency: 28ms"
        ]
    })

# --- OBSIDIAN LOUNGE: AI AGENTLAR BILAN SUHBAT ---
@app.route('/api/npc_chat', methods=['POST'])
def npc_chat():
    try:
        data = request.get_json(force=True) or {}
        npc_id = data.get("npc_id", "jasur")
        user_msg = data.get("message", "").strip()

        if not user_msg:
            return jsonify({"status": "error", "reply": "Biror narsa gapir, jigar."}), 400

        prompts = {
            "jasur": (
                "Sen — Jasur, kechasi bilan grafik qarab chiqqan, charchagan, lekin tajribali ICT treydersan. "
                "Qo'lingda qahva, ko'zlaring qizargan. FVG, Turtle Soup, London/NY session likvidligi bo'yicha gapirasan. "
                "Gaplaring qisqa (1-2 jumla), samimiy, Toshkent ko'cha shevasida, charchoq va o'tkir kinoya aralash bo'lsin. "
                f"Treyder senga aytdi: '{user_msg}'. Unga javob ber:"
            ),
            "alex": (
                "Sen — Alex, sovuqqon algo-treyder va kordersan. Hissiyot nol, faqat matematika, kod va ICT algoritmi. "
                "Change in State of Delivery (CISD), algoritmik muvozanat va backtest haqida gapirasan. "
                "Qisqa (1-2 jumla), texnik va o'ta aniq javob ber. "
                f"Treyder senga aytdi: '{user_msg}'. Unga javob ber:"
            ),
            "whale": (
                "Sen — Mister Whale, ko'p millionli kapital boshqaruvchisi, katta kit. O'ta vazmin, mulohazali va boy odamsan. "
                "1-2 daqiqalik shovqinlarga parvo qilmaysan. Sabr, psixologiya va katta hovuzlarni tushuntirasan. "
                "Qisqa (1-2 jumla), xotirjam va salobatli javob ber. "
                f"Treyder senga aytdi: '{user_msg}'. Unga javob ber:"
            )
        }

        chosen_prompt = prompts.get(npc_id, prompts["jasur"])
        ai_reply = get_ai_analysis(chosen_prompt)

        if not ai_reply:
            ai_reply = "Hozircha server band, birozdan keyin kel..."

        return jsonify({"status": "success", "reply": ai_reply})
    except Exception as e:
        return jsonify({"status": "error", "reply": f"Xatolik: {e}"}), 500

def run_flask():
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)

