import datetime

user_histories = {}
comments_store = []

latest_ict_status = {
    "BTC": "Scanning 15m FVG Liquidity...",
    "ETH": "Monitoring CISD delivery...",
    "last_signal": "No high-probability setup yet",
    "active_agents": 3,
}

sent_trade_ids = set()
SEEN_NEWS = set()
