OBSIDIAN BOT — CLEAN STRUCTURE

Root start command:
    python bot.py

Files:
    bot.py          Render entry point
    main.py         Startup, webhook, background workers
    config.py       Environment variables
    clients.py      Telegram / Flask / AI / Google clients
    ai.py            Gemini + Groq
    sheets.py        Google Sheets
    web.py           Flask + HQ API
    handlers.py      Telegram commands and chat
    radar.py         ICT/SMC scanner
    monitoring.py    Google Sheets monitor
    news.py          Crypto news

Required:
    TELEGRAM_BOT_TOKEN

Optional:
    GEMINI_API_KEY
    GROQ_API_KEY
    SPREADSHEET_ID
    GOOGLE_CREDENTIALS_JSON
    CHANNEL_CHAT_ID
    ADMIN_CHAT_ID
    ADMIN_USER_IDS
    WEBHOOK_BASE_URL

WEBHOOK:
    Default URL is https://tradebot-xelo.onrender.com
    Do not run a second copy of the same Telegram bot token with polling.
